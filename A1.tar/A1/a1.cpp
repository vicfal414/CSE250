// File: a1.cpp
// Victoria
// Faltisco
// I AFFIRM THAT WHEN WORKING ON THIS ASSIGNMENT
// I WILL FOLLOW UB STUDENT CODE OF CONDUCT, AND
// I WILL NOT VIOLATE ACADEMIC INTEGRITY RULES

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

int main(int argc, char const *argv[])
{
	//reading file, store into dna_seq
	std::string dna_seq;
	std::fstream theFile (argv[1]);
	std::string line;
	while (std::getline(theFile, line)){
			dna_seq = line;
	}
	theFile.close();
	

	// saving number k
	int const k = atoi(argv[2]);
	int length = dna_seq.length();
	int number = length - k + 1;
	
	//saving number t
	int t = atoi(argv[3]);

	//counts for each letter
	int countA = 0;
	int countC = 0;
	int countG = 0;
	int countT = 0;
	for (char q : dna_seq){
		if (q=='A'){countA=countA+1;}
		if (q=='C'){countC=countC+1;}
		if (q=='G'){countG=countG+1;}
		if (q=='T'){countT=countT+1;}
	}

	//output numbers
	std::cout << "0 " << k << " " << length << std::endl;
	std::cout << "1 " << countA << " " << countC << " " ;
	std::cout << countG << " " << countT << std::endl;


	//error message
	if (length < k) {
		std::cout << "error" << std::endl;
		return 0;
	}


	int i = 0;
	//number of elements in array
	int powerNum = pow(4,k);
	//list of counts
	int* kmerList_count = new int[powerNum]{0};
	std::string* kmerList_letter = new std::string[powerNum];

	while (i<number){
		std::string kmer = dna_seq.substr(i,k);
		int* numArray = new int[k];
		int c = 0;
		for (char b : kmer){
			if(b=='A'){numArray[c]=0;}
			if(b=='C'){numArray[c]=1;}
			if(b=='G'){numArray[c]=2;}
			if(b=='T'){numArray[c]=3;}
			c=c+1;
		}
		//test numArray
		//std::cout<<"numbers: ";
		// for (int x=0; x<k; x++){
		// 	std::cout<<numArray[x];
		// }
		//std::cout<<" "<<std::endl;

		int base10 = 0;
		for (int x=0; x<k; x++){
			base10 = base10 + (numArray[x] * (pow(4,k-x-1)));
		//	std::cout<<"base10 var:"<<base10<<std::endl;
		}
		kmerList_count[base10] = kmerList_count[base10]+1;
		kmerList_letter[base10] = kmer;
		//std::cout<<"list:"<<kmer_list[base10]<<std::endl;
		delete[] numArray;
		i=i+1;
	}

	//std::cout<<"powerNum: " << powerNum <<std::endl;
	
	 for (int qwe=0; qwe<powerNum; qwe=qwe+1){
	 	if (kmerList_count[qwe]>=t){
	 		std::cout<<kmerList_letter[qwe];
	 		std::cout<<" "<<kmerList_count[qwe]<<std::endl;
	 	}
	 }

	delete[] kmerList_count;
	delete[] kmerList_letter;
	return 0;
}